package ai.friday.osmobile

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val apiBase = "https://friday-ai-backend-gfc4.onrender.com"
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: Button

    private val bg = Color.rgb(5, 12, 22)
    private val panel = Color.rgb(12, 25, 40)
    private val cyan = Color.rgb(0, 220, 255)
    private val white = Color.rgb(230, 245, 255)
    private val muted = Color.rgb(145, 173, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        addMessage("SYSTEM", "F.R.I.D.A.Y. OS Mobile запущена. Проверяю подключение к серверу…", false)
        checkServer()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(12))
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "F.R.I.D.A.Y."
            textSize = 27f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "OS MOBILE  •  STAGE 1"
            textSize = 11f
            letterSpacing = 0.18f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(subtitle, matchWrap())

        status = TextView(this).apply {
            text = "● Проверка сервера…"
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(panel, 12)
        }
        root.addView(status, matchWrap())

        scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setPadding(0, dp(12), 0, dp(12))
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Напиши F.R.I.D.A.Y.…"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(panel, 14)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendMessage()
                    true
                } else false
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            marginEnd = dp(8)
        })

        sendButton = Button(this).apply {
            text = "SEND"
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.BLACK)
            background = rounded(cyan, 14)
            setOnClickListener { sendMessage() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(dp(82), dp(50)))
        root.addView(composer, matchWrap())
        setContentView(root)
    }

    private fun checkServer() {
        executor.execute {
            try {
                val result = request("GET", "$apiBase/health", null)
                runOnUiThread {
                    status.text = if (result.first in 200..299) "● Сервер доступен" else "● Сервер ответил: HTTP ${result.first}"
                    status.setTextColor(if (result.first in 200..299) cyan else Color.rgb(255, 180, 80))
                    if (result.first !in 200..299) addMessage("SYSTEM", "Сервер ответил кодом ${result.first}.", false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "● Нет соединения с сервером"
                    status.setTextColor(Color.rgb(255, 120, 120))
                    addMessage("SYSTEM", "Не удалось проверить сервер. Проверь интернет и попробуй ещё раз.", false)
                }
            }
        }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        addMessage("YOU", message, true)
        input.setText("")
        sendButton.isEnabled = false
        sendButton.alpha = 0.6f
        addMessage("F.R.I.D.A.Y.", "Обрабатываю запрос…", false)

        executor.execute {
            try {
                val payload = JSONObject().put("message", message).toString()
                val (code, body) = request("POST", "$apiBase/chat", payload)
                val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
                val reply = if (code in 200..299) {
                    json.optString("reply", "Сервер ответил, но поле reply отсутствует.")
                } else {
                    val detail = json.optString("detail", "HTTP $code")
                    "Ошибка сервера (HTTP $code): $detail"
                }
                runOnUiThread {
                    removeLastLoadingMessage()
                    addMessage("F.R.I.D.A.Y.", reply, false)
                    sendButton.isEnabled = true
                    sendButton.alpha = 1f
                }
            } catch (e: Exception) {
                runOnUiThread {
                    removeLastLoadingMessage()
                    addMessage("SYSTEM", "Не удалось выполнить запрос. Проверь соединение и доступность сервера.", false)
                    sendButton.isEnabled = true
                    sendButton.alpha = 1f
                }
            }
        }
    }

    private fun request(method: String, endpoint: String, body: String?): Pair<Int, String> {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 45000
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) {
                connection.outputStream.use {
                    it.write(body.toByteArray(StandardCharsets.UTF_8))
                }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            connection.disconnect()
        }
    }

    private fun addMessage(who: String, message: String, isUser: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(if (isUser) Color.rgb(10, 46, 61) else panel, 14)
        }
        val label = TextView(this).apply {
            text = who
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(if (isUser) cyan else muted)
            typeface = Typeface.DEFAULT_BOLD
        }
        val body = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(white)
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(label)
        card.addView(body)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(9) }
        chat.addView(card, params)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun removeLastLoadingMessage() {
        if (chat.childCount > 0) {
            val last = chat.getChildAt(chat.childCount - 1)
            if (last is LinearLayout && last.childCount > 1) {
                val label = last.getChildAt(0) as? TextView
                val body = last.getChildAt(1) as? TextView
                if (label?.text == "F.R.I.D.A.Y." && body?.text == "Обрабатываю запрос…") {
                    chat.removeView(last)
                }
            }
        }
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
